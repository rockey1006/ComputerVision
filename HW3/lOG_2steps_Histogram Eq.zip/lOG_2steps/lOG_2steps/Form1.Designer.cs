﻿namespace lOG_2steps
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.btnLoadImage = new System.Windows.Forms.Button();
            this.picOrig = new System.Windows.Forms.PictureBox();
            this.picProcessed = new System.Windows.Forms.PictureBox();
            this.btnLoG1 = new System.Windows.Forms.Button();
            this.btnLoGDireFliter = new System.Windows.Forms.Button();
            this.btnHistogramEq = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.picOrig)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picProcessed)).BeginInit();
            this.SuspendLayout();
            // 
            // btnLoadImage
            // 
            this.btnLoadImage.Location = new System.Drawing.Point(20, 29);
            this.btnLoadImage.Name = "btnLoadImage";
            this.btnLoadImage.Size = new System.Drawing.Size(96, 35);
            this.btnLoadImage.TabIndex = 0;
            this.btnLoadImage.Text = "Load Image";
            this.btnLoadImage.UseVisualStyleBackColor = true;
            this.btnLoadImage.Click += new System.EventHandler(this.btnLoadImage_Click);
            // 
            // picOrig
            // 
            this.picOrig.Location = new System.Drawing.Point(138, 28);
            this.picOrig.Name = "picOrig";
            this.picOrig.Size = new System.Drawing.Size(640, 480);
            this.picOrig.TabIndex = 1;
            this.picOrig.TabStop = false;
            // 
            // picProcessed
            // 
            this.picProcessed.Location = new System.Drawing.Point(812, 29);
            this.picProcessed.Name = "picProcessed";
            this.picProcessed.Size = new System.Drawing.Size(640, 480);
            this.picProcessed.TabIndex = 2;
            this.picProcessed.TabStop = false;
            // 
            // btnLoG1
            // 
            this.btnLoG1.Location = new System.Drawing.Point(20, 95);
            this.btnLoG1.Name = "btnLoG1";
            this.btnLoG1.Size = new System.Drawing.Size(96, 35);
            this.btnLoG1.TabIndex = 3;
            this.btnLoG1.Text = "LoG_2 steps";
            this.btnLoG1.UseVisualStyleBackColor = true;
            this.btnLoG1.Click += new System.EventHandler(this.btnLoG1_Click);
            // 
            // btnLoGDireFliter
            // 
            this.btnLoGDireFliter.Location = new System.Drawing.Point(20, 160);
            this.btnLoGDireFliter.Name = "btnLoGDireFliter";
            this.btnLoGDireFliter.Size = new System.Drawing.Size(96, 35);
            this.btnLoGDireFliter.TabIndex = 4;
            this.btnLoGDireFliter.Text = "LoG_Direct Fliter";
            this.btnLoGDireFliter.UseVisualStyleBackColor = true;
            this.btnLoGDireFliter.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnHistogramEq
            // 
            this.btnHistogramEq.Location = new System.Drawing.Point(20, 226);
            this.btnHistogramEq.Name = "btnHistogramEq";
            this.btnHistogramEq.Size = new System.Drawing.Size(96, 35);
            this.btnHistogramEq.TabIndex = 5;
            this.btnHistogramEq.Text = "Histogram Equalization";
            this.btnHistogramEq.UseVisualStyleBackColor = true;
            this.btnHistogramEq.Click += new System.EventHandler(this.btnHistogramEq_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1480, 537);
            this.Controls.Add(this.btnHistogramEq);
            this.Controls.Add(this.btnLoGDireFliter);
            this.Controls.Add(this.btnLoG1);
            this.Controls.Add(this.picProcessed);
            this.Controls.Add(this.picOrig);
            this.Controls.Add(this.btnLoadImage);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.picOrig)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picProcessed)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnLoadImage;
        private System.Windows.Forms.PictureBox picOrig;
        private System.Windows.Forms.PictureBox picProcessed;
        private System.Windows.Forms.Button btnLoG1;
        private System.Windows.Forms.Button btnLoGDireFliter;
        private System.Windows.Forms.Button btnHistogramEq;
    }
}

