﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace lOG_2steps
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        double g = 1.0;
        double f = -0.125;//0.5;
 

        private void btnLoadImage_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.InitialDirectory = "G:\\CS585\\Images";
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                Bitmap bmp = new Bitmap(ofd.FileName);
                picOrig.Image = bmp;
                MessageBox.Show("The image is loaded!");
            }
        }

        private void btnLoG1_Click(object sender, EventArgs e)
        {
            try
            {
                Bitmap bmp = new Bitmap(picOrig.Image);
                double[][] kernel = new double[3][];
                double[][] kernelX = new double[3][];
                double[][] kernelY = new double[3][];

                for (int i = 0; i < 3; i++)
                    kernel[i] = new double[3];

                // Gaussian: 5
                kernel[0][0] = -1 * g;
                kernel[0][1] = -1 * g;
                kernel[0][2] = -1 * g;
                kernel[1][0] = -1 * g;
                kernel[1][1] = 8 * g;
                kernel[1][2] = -1 * g;
                kernel[2][0] = -1 * g;
                kernel[2][1] = -1 * g;
                kernel[2][2] = -1 * g;

                Bitmap bmpOrig = (Bitmap)bmp.Clone();
                MyImageProc.Convolve(bmp, kernel);
                //picOrig.Image = bmpOrig;
                //picProcessed.Image = bmp;
                //MessageBox.Show("done..");

                for (int i = 0; i < 3; i++)
                    kernelX[i] = new double[3];

                // Gradient (X-axis) : 7
                kernelX[0][0] = -1;
                kernelX[0][1] = 0;
                kernelX[0][2] = 1;
                kernelX[1][0] = -1;
                kernelX[1][1] = 0;
                kernelX[1][2] = 1;
                kernelX[2][0] = -1;
                kernelX[2][1] = 0;
                kernelX[2][2] = 1;

                for (int i = 0; i < 3; i++)
                    kernelY[i] = new double[3];

                // Gradient (Y-axis) : 8
                kernelY[0][0] = 1;
                kernelY[0][1] = 1;
                kernelY[0][2] = 1;
                kernelY[1][0] = 0;
                kernelY[1][1] = 0;
                kernelY[1][2] = 0;
                kernelY[2][0] = -1;
                kernelY[2][1] = -1;
                kernelY[2][2] = -1;

                //Bitmap bmpOrig = (Bitmap)bmp.Clone();
                Gradient.Combine(bmp, kernelX, kernelY);
                picOrig.Image = bmpOrig;
                //picProcessed.Image = bmp;

                //bmp = new Bitmap(bmp.Width, bmpOrig.Height);
                

                int width = bmpOrig.Width;
                int height = bmpOrig.Height;

                for (int x = 0; x < width; x++)
                {
                    for (int y = 0; y < height; y++)
                    {
                        Color currentPixelOrig;
                        Color currentPixelProc;

                        currentPixelOrig = bmpOrig.GetPixel(x, y);
                        currentPixelProc = bmp.GetPixel(x, y);

                        int red = (currentPixelOrig.R + currentPixelProc.R)/2;

                        int green = (currentPixelOrig.G + currentPixelProc.G)/2;

                        int blue = (currentPixelOrig.B + currentPixelProc.B)/2;

                        int gray = (int)(0.299 * red + 0.587 * green + 0.114 * blue);
                        bmp.SetPixel(x, y, Color.FromArgb(red, green, blue));
                        
                    }
                }
                picProcessed.Image = bmp;

            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                Bitmap bmp = new Bitmap(picOrig.Image);
                double[][] kernel = new double[3][];

                for (int i = 0; i < 3; i++)
                    kernel[i] = new double[3];

                // Derict LoG fliter : sigma = 1.0
                kernel[0][0] = 0 / f;
                kernel[0][1] = -1 / f;
                kernel[0][2] = 0 / f;
                kernel[1][0] = -1 / f;
                kernel[1][1] = 4 / f;
                kernel[1][2] = -1 / f;
                kernel[2][0] = 0 / f;
                kernel[2][1] = -1 / f;
                kernel[2][2] = 0 / f;

                Bitmap bmpOrig = (Bitmap)bmp.Clone();
                MyImageProc.Convolve(bmp, kernel);
                picOrig.Image = bmpOrig;
                //picProcessed.Image = bmp;
                //MessageBox.Show("done..");

                int width = bmpOrig.Width;
                int height = bmpOrig.Height;

                for (int x = 0; x < width; x++)
                {
                    for (int y = 0; y < height; y++)
                    {
                        Color currentPixelOrig;
                        Color currentPixelProc;

                        currentPixelOrig = bmpOrig.GetPixel(x, y);
                        currentPixelProc = bmp.GetPixel(x, y);

                        int red = (currentPixelOrig.R + currentPixelProc.R) / 2;

                        int green = (currentPixelOrig.G + currentPixelProc.G) / 2;

                        int blue = (currentPixelOrig.B + currentPixelProc.B) / 2;

                        bmp.SetPixel(x, y, Color.FromArgb(red, green, blue));

                    }
                }
                picProcessed.Image = bmp;

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnHistogramEq_Click(object sender, EventArgs e)
        {
            try
            {
                Bitmap bmp = new Bitmap(picOrig.Image);
                Bitmap bmpOrig = (Bitmap)bmp.Clone();
                int width = bmpOrig.Width;
                int height = bmpOrig.Height;

                int r = 0;
                int g = 0;
                int b = 0;

               int[] cdfR = new int[256];
               int[] cdfG = new int[256];
               int[] cdfB = new int[256];
 

                for (int x = 0; x < width; x++)
                {
                    for (int y = 0; y < height; y++)
                    {
                        Color currentPixel;

                        currentPixel = bmpOrig.GetPixel(x, y);

                        int red = currentPixel.R;
                        int green = currentPixel.G;
                        int blue = currentPixel.B;

                        cdfR[red] += 1;
                        cdfG[green] += 1;
                        cdfB[blue] += 1;

                    }
                }

                int maxR = 0;
                int maxG = 0;
                int maxB = 0;

                int minR = 0;
                int minG = 0;
                int minB = 0;

                foreach (int a in cdfR)
                {
                    if (a >= maxR)
                        maxR = a;
                    if (a < minR)
                        minR = a;
                }

                foreach (int a in cdfG)
                {
                    if (a >= maxG)
                        maxG = a;
                    if (a < minG)
                        minG = a;
                }

                foreach (int a in cdfB)
                {
                    if (a >= maxB)
                        maxR = a;
                    if (a < minB)
                        minB = a;
                }

                for (int n = 0; n < 255; n++)
                {
                    if (cdfR[n] > 0)
                        r += 1;
                    if (cdfG[n] > 0)
                        g += 1;
                    if (cdfB[n] > 0)
                        b += 1;
                }


                for (int l = 0; l < 254; l++)
                {
                    cdfR[l + 1] = cdfR[l + 1] + cdfR[l];
                    cdfG[l + 1] = cdfG[l + 1] + cdfG[l];
                    cdfB[l + 1] = cdfB[l + 1] + cdfB[l];
                }

                int[] hvR = cdfR;
                int[] hvG = cdfG;
                int[] hvB = cdfB;

                for (int ll = 0; ll < 255; ll++)
                {
                    hvR[ll] = ((cdfR[ll] - minR) * 255 / (width * height - 1));
                    hvG[ll] = ((cdfG[ll] - minG) * 255 / (width * height - 1)) ;
                    hvB[ll] = ((cdfB[ll] - minB) * 255 / (width * height - 1)) ;
                }

                for (int x = 0; x < width; x++)
                {
                    for (int y = 0; y < height; y++)
                    {
                        Color currentPixel;

                        currentPixel = bmpOrig.GetPixel(x, y);

                        int redn = hvR[currentPixel.R];
                        int greenn = hvG[currentPixel.G];
                        int bluen = hvB[currentPixel.B];


                        if (redn > 255) redn = 255;
                        if (greenn > 255) greenn = 255;
                        if (bluen > 255) bluen = 255;                     

                        bmp.SetPixel(x, y, Color.FromArgb(redn, greenn, bluen));;
                    }
                }


                picProcessed.Image = bmp;

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
