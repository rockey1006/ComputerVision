﻿namespace ConvolFilters
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnConvolve = new System.Windows.Forms.Button();
            this.picOrig = new System.Windows.Forms.PictureBox();
            this.picProcessed = new System.Windows.Forms.PictureBox();
            this.btnLoadPicture = new System.Windows.Forms.Button();
            this.btnLowPass = new System.Windows.Forms.Button();
            this.btnHighPass = new System.Windows.Forms.Button();
            this.btnSharpening = new System.Windows.Forms.Button();
            this.btnGaussian = new System.Windows.Forms.Button();
            this.btnLaplacian = new System.Windows.Forms.Button();
            this.btnFirstDerivative = new System.Windows.Forms.Button();
            this.btnFirstDerY = new System.Windows.Forms.Button();
            this.btnGradient = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.picOrig)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picProcessed)).BeginInit();
            this.SuspendLayout();
            // 
            // btnConvolve
            // 
            this.btnConvolve.Location = new System.Drawing.Point(11, 95);
            this.btnConvolve.Margin = new System.Windows.Forms.Padding(2);
            this.btnConvolve.Name = "btnConvolve";
            this.btnConvolve.Size = new System.Drawing.Size(116, 25);
            this.btnConvolve.TabIndex = 0;
            this.btnConvolve.Text = "Identity";
            this.btnConvolve.UseVisualStyleBackColor = true;
            this.btnConvolve.Click += new System.EventHandler(this.btnConvolve_Click);
            // 
            // picOrig
            // 
            this.picOrig.Location = new System.Drawing.Point(153, 28);
            this.picOrig.Margin = new System.Windows.Forms.Padding(2);
            this.picOrig.Name = "picOrig";
            this.picOrig.Size = new System.Drawing.Size(640, 480);
            this.picOrig.TabIndex = 1;
            this.picOrig.TabStop = false;
            // 
            // picProcessed
            // 
            this.picProcessed.Location = new System.Drawing.Point(823, 28);
            this.picProcessed.Margin = new System.Windows.Forms.Padding(2);
            this.picProcessed.Name = "picProcessed";
            this.picProcessed.Size = new System.Drawing.Size(640, 480);
            this.picProcessed.TabIndex = 2;
            this.picProcessed.TabStop = false;
            // 
            // btnLoadPicture
            // 
            this.btnLoadPicture.Location = new System.Drawing.Point(11, 28);
            this.btnLoadPicture.Name = "btnLoadPicture";
            this.btnLoadPicture.Size = new System.Drawing.Size(114, 35);
            this.btnLoadPicture.TabIndex = 3;
            this.btnLoadPicture.Text = "Load Picture";
            this.btnLoadPicture.UseVisualStyleBackColor = true;
            this.btnLoadPicture.Click += new System.EventHandler(this.btnLoadPicture_Click);
            // 
            // btnLowPass
            // 
            this.btnLowPass.Location = new System.Drawing.Point(9, 144);
            this.btnLowPass.Margin = new System.Windows.Forms.Padding(2);
            this.btnLowPass.Name = "btnLowPass";
            this.btnLowPass.Size = new System.Drawing.Size(116, 25);
            this.btnLowPass.TabIndex = 4;
            this.btnLowPass.Text = "Low Pass";
            this.btnLowPass.UseVisualStyleBackColor = true;
            this.btnLowPass.Click += new System.EventHandler(this.btnLowPass_Click);
            // 
            // btnHighPass
            // 
            this.btnHighPass.Location = new System.Drawing.Point(9, 193);
            this.btnHighPass.Margin = new System.Windows.Forms.Padding(2);
            this.btnHighPass.Name = "btnHighPass";
            this.btnHighPass.Size = new System.Drawing.Size(116, 25);
            this.btnHighPass.TabIndex = 5;
            this.btnHighPass.Text = "High Pass";
            this.btnHighPass.UseVisualStyleBackColor = true;
            this.btnHighPass.Click += new System.EventHandler(this.btnHighPass_Click);
            // 
            // btnSharpening
            // 
            this.btnSharpening.Location = new System.Drawing.Point(9, 245);
            this.btnSharpening.Margin = new System.Windows.Forms.Padding(2);
            this.btnSharpening.Name = "btnSharpening";
            this.btnSharpening.Size = new System.Drawing.Size(116, 25);
            this.btnSharpening.TabIndex = 6;
            this.btnSharpening.Text = "Sharpeness";
            this.btnSharpening.UseVisualStyleBackColor = true;
            this.btnSharpening.Click += new System.EventHandler(this.btnSharpening_Click);
            // 
            // btnGaussian
            // 
            this.btnGaussian.Location = new System.Drawing.Point(9, 299);
            this.btnGaussian.Margin = new System.Windows.Forms.Padding(2);
            this.btnGaussian.Name = "btnGaussian";
            this.btnGaussian.Size = new System.Drawing.Size(116, 25);
            this.btnGaussian.TabIndex = 7;
            this.btnGaussian.Text = "Gaussian";
            this.btnGaussian.UseVisualStyleBackColor = true;
            this.btnGaussian.Click += new System.EventHandler(this.btnGaussian_Click);
            // 
            // btnLaplacian
            // 
            this.btnLaplacian.Location = new System.Drawing.Point(9, 483);
            this.btnLaplacian.Margin = new System.Windows.Forms.Padding(2);
            this.btnLaplacian.Name = "btnLaplacian";
            this.btnLaplacian.Size = new System.Drawing.Size(116, 25);
            this.btnLaplacian.TabIndex = 8;
            this.btnLaplacian.Text = "Laplacian";
            this.btnLaplacian.UseVisualStyleBackColor = true;
            this.btnLaplacian.Click += new System.EventHandler(this.btnLaplacian_Click);
            // 
            // btnFirstDerivative
            // 
            this.btnFirstDerivative.Location = new System.Drawing.Point(9, 363);
            this.btnFirstDerivative.Margin = new System.Windows.Forms.Padding(2);
            this.btnFirstDerivative.Name = "btnFirstDerivative";
            this.btnFirstDerivative.Size = new System.Drawing.Size(116, 25);
            this.btnFirstDerivative.TabIndex = 9;
            this.btnFirstDerivative.Text = "First Derivative (X)";
            this.btnFirstDerivative.UseVisualStyleBackColor = true;
            this.btnFirstDerivative.Click += new System.EventHandler(this.btnFirstDerivative_Click);
            // 
            // btnFirstDerY
            // 
            this.btnFirstDerY.Location = new System.Drawing.Point(9, 392);
            this.btnFirstDerY.Margin = new System.Windows.Forms.Padding(2);
            this.btnFirstDerY.Name = "btnFirstDerY";
            this.btnFirstDerY.Size = new System.Drawing.Size(116, 25);
            this.btnFirstDerY.TabIndex = 11;
            this.btnFirstDerY.Text = "First Derivative (Y)";
            this.btnFirstDerY.UseVisualStyleBackColor = true;
            this.btnFirstDerY.Click += new System.EventHandler(this.btnFirstDerY_Click);
            // 
            // btnGradient
            // 
            this.btnGradient.Location = new System.Drawing.Point(9, 421);
            this.btnGradient.Margin = new System.Windows.Forms.Padding(2);
            this.btnGradient.Name = "btnGradient";
            this.btnGradient.Size = new System.Drawing.Size(116, 25);
            this.btnGradient.TabIndex = 12;
            this.btnGradient.Text = "Gradient (X+Y)";
            this.btnGradient.UseVisualStyleBackColor = true;
            this.btnGradient.Click += new System.EventHandler(this.btnGradient_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1490, 555);
            this.Controls.Add(this.btnGradient);
            this.Controls.Add(this.btnFirstDerY);
            this.Controls.Add(this.btnFirstDerivative);
            this.Controls.Add(this.btnLaplacian);
            this.Controls.Add(this.btnGaussian);
            this.Controls.Add(this.btnSharpening);
            this.Controls.Add(this.btnHighPass);
            this.Controls.Add(this.btnLowPass);
            this.Controls.Add(this.btnLoadPicture);
            this.Controls.Add(this.picProcessed);
            this.Controls.Add(this.picOrig);
            this.Controls.Add(this.btnConvolve);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.picOrig)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picProcessed)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnConvolve;
        private System.Windows.Forms.PictureBox picOrig;
        private System.Windows.Forms.PictureBox picProcessed;
        private System.Windows.Forms.Button btnLoadPicture;
        private System.Windows.Forms.Button btnLowPass;
        private System.Windows.Forms.Button btnHighPass;
        private System.Windows.Forms.Button btnSharpening;
        private System.Windows.Forms.Button btnGaussian;
        private System.Windows.Forms.Button btnLaplacian;
        private System.Windows.Forms.Button btnFirstDerivative;
        private System.Windows.Forms.Button btnFirstDerY;
        private System.Windows.Forms.Button btnGradient;
    }
}

