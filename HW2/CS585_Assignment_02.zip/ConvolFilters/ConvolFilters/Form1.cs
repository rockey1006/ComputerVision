﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ConvolFilters
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        double f = 0.7; // 0 < f < 1
        double g = 0.0625;//0.00625; //0.125;

        private void btnLoadPicture_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.InitialDirectory = "G:\\CS585\\Images";
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                Bitmap bmp = new Bitmap(ofd.FileName);
                picOrig.Image = bmp;
                MessageBox.Show("The image is loaded!");
            }
        }

        private void btnConvolve_Click(object sender, EventArgs e)
        {
            try
            {
                Bitmap bmp = new Bitmap(picOrig.Image);
                double[][] kernel = new double[3][];

                for (int i = 0; i < 3; i++)
                kernel[i] = new double[3];

                // Identity : 1
                kernel[0][0] = 0;
                kernel[0][1] = 0;
                kernel[0][2] = 0;
                kernel[1][0] = 0;
                kernel[1][1] = 1;
                kernel[1][2] = 0;
                kernel[2][0] = 0;
                kernel[2][1] = 0;
                kernel[2][2] = 0;

                Bitmap bmpOrig = (Bitmap)bmp.Clone();
                MyImageProc.Convolve(bmp, kernel);
                picOrig.Image = bmpOrig;
                picProcessed.Image = bmp;
                //MessageBox.Show("done..");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnLowPass_Click(object sender, EventArgs e)
        {
            try
            {
                Bitmap bmp = new Bitmap(picOrig.Image);
                double[][] kernel = new double[3][];

                for (int i = 0; i < 3; i++)
                    kernel[i] = new double[3];

                // Low Pass : 2
                kernel[0][0] = 1 / 9.0;
                kernel[0][1] = 1 / 9.0;
                kernel[0][2] = 1 / 9.0;
                kernel[1][0] = 1 / 9.0;
                kernel[1][1] = 1 / 9.0;
                kernel[1][2] = 1 / 9.0;
                kernel[2][0] = 1 / 9.0;
                kernel[2][1] = 1 / 9.0;
                kernel[2][2] = 1 / 9.0;

                Bitmap bmpOrig = (Bitmap)bmp.Clone();
                MyImageProc.Convolve(bmp, kernel);
                picOrig.Image = bmpOrig;
                picProcessed.Image = bmp;
                //MessageBox.Show("done..");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnHighPass_Click(object sender, EventArgs e)
        {
            try
            {
                Bitmap bmp = new Bitmap(picOrig.Image);
                double[][] kernel = new double[3][];

                for (int i = 0; i < 3; i++)
                    kernel[i] = new double[3];

                // High Pass : 3
                kernel[0][0] = -1;
                kernel[0][1] = -1;
                kernel[0][2] = -1;
                kernel[1][0] = -1;
                kernel[1][1] = 8;
                kernel[1][2] = -1;
                kernel[2][0] = -1;
                kernel[2][1] = -1;
                kernel[2][2] = -1;

                Bitmap bmpOrig = (Bitmap)bmp.Clone();
                MyImageProc.Convolve(bmp, kernel);
                picOrig.Image = bmpOrig;
                picProcessed.Image = bmp;
                //MessageBox.Show("done..");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnSharpening_Click(object sender, EventArgs e)
        {
            try
            {
                Bitmap bmp = new Bitmap(picOrig.Image);
                double[][] kernel = new double[3][];

                for (int i = 0; i < 3; i++)
                    kernel[i] = new double[3];

                // Sharpening : 4
                kernel[0][0] = -f;
                kernel[0][1] = -f;
                kernel[0][2] = -f;
                kernel[1][0] = -f;
                kernel[1][1] = 9 - f;
                kernel[1][2] = -f;
                kernel[2][0] = -f;
                kernel[2][1] = -f;
                kernel[2][2] = -f;

                Bitmap bmpOrig = (Bitmap)bmp.Clone();
                MyImageProc.Convolve(bmp, kernel);
                picOrig.Image = bmpOrig;
                picProcessed.Image = bmp;
                //MessageBox.Show("done..");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnGaussian_Click(object sender, EventArgs e)
        {
            try
            {
                Bitmap bmp = new Bitmap(picOrig.Image);
                double[][] kernel = new double[3][];

                for (int i = 0; i < 3; i++)
                    kernel[i] = new double[3];

                // Gaussian: 5
                kernel[0][0] = 1 * g;
                kernel[0][1] = 2 * g;
                kernel[0][2] = 1 * g;
                kernel[1][0] = 2 * g;
                kernel[1][1] = 4 * g;
                kernel[1][2] = 2 * g;
                kernel[2][0] = 1 * g;
                kernel[2][1] = 2 * g;
                kernel[2][2] = 1 * g;

                Bitmap bmpOrig = (Bitmap)bmp.Clone();
                MyImageProc.Convolve(bmp, kernel);
                picOrig.Image = bmpOrig;
                picProcessed.Image = bmp;
                //MessageBox.Show("done..");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnLaplacian_Click(object sender, EventArgs e)
        {
            try
            {
                Bitmap bmp = new Bitmap(picOrig.Image);
                double[][] kernel = new double[3][];

                for (int i = 0; i < 3; i++)
                    kernel[i] = new double[3];

                // n-neighbor Laplacian : 6
                kernel[0][0] = 0;
                kernel[0][1] = -1;
                kernel[0][2] = 0;
                kernel[1][0] = -1;
                kernel[1][1] = 4;
                kernel[1][2] = -1;
                kernel[2][0] = 0;
                kernel[2][1] = -1;
                kernel[2][2] = 0;

                Bitmap bmpOrig = (Bitmap)bmp.Clone();
                MyImageProc.Convolve(bmp, kernel);
                picOrig.Image = bmpOrig;
                picProcessed.Image = bmp;
                //MessageBox.Show("done..");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnFirstDerivative_Click(object sender, EventArgs e)
        {
            try
            {
                Bitmap bmp = new Bitmap(picOrig.Image);
                double[][] kernel = new double[3][];

                for (int i = 0; i < 3; i++)
                    kernel[i] = new double[3];

                // First derivative (X-axis) : 7
                kernel[0][0] = -1;
                kernel[0][1] = 0;
                kernel[0][2] = 1;
                kernel[1][0] = -1;
                kernel[1][1] = 0;
                kernel[1][2] = 1;
                kernel[2][0] = -1;
                kernel[2][1] = 0;
                kernel[2][2] = 1;

                Bitmap bmpOrig = (Bitmap)bmp.Clone();
                MyImageProc.Convolve(bmp, kernel);
                picOrig.Image = bmpOrig;
                picProcessed.Image = bmp;
                //MessageBox.Show("done..");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        
        private void btnFirstDerY_Click(object sender, EventArgs e)
        {
            try
            {
                Bitmap bmp = new Bitmap(picOrig.Image);
                double[][] kernel = new double[3][];

                for (int i = 0; i < 3; i++)
                    kernel[i] = new double[3];

                // First derivative (Y-axis) : 8
                kernel[0][0] = 1;
                kernel[0][1] = 1;
                kernel[0][2] = 1;
                kernel[1][0] = 0;
                kernel[1][1] = 0;
                kernel[1][2] = 0;
                kernel[2][0] = -1;
                kernel[2][1] = -1;
                kernel[2][2] = -1;

                Bitmap bmpOrig = (Bitmap)bmp.Clone();
                MyImageProc.Convolve(bmp, kernel);
                picOrig.Image = bmpOrig;
                picProcessed.Image = bmp;
                //MessageBox.Show("done..");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnGradient_Click(object sender, EventArgs e)
        {

            try
            {
                Bitmap bmp = new Bitmap(picOrig.Image);
                double[][] kernelX = new double[3][];
                double[][] kernelY = new double[3][];

                for (int i = 0; i < 3; i++)
                    kernelX[i] = new double[3];

                // Gradient (X-axis) : 7
                kernelX[0][0] = -1;
                kernelX[0][1] = 0;
                kernelX[0][2] = 1;
                kernelX[1][0] = -1;
                kernelX[1][1] = 0;
                kernelX[1][2] = 1;
                kernelX[2][0] = -1;
                kernelX[2][1] = 0;
                kernelX[2][2] = 1;

                for (int i = 0; i < 3; i++)
                    kernelY[i] = new double[3];

                // Gradient (Y-axis) : 8
                kernelY[0][0] = 1;
                kernelY[0][1] = 1;
                kernelY[0][2] = 1;
                kernelY[1][0] = 0;
                kernelY[1][1] = 0;
                kernelY[1][2] = 0;
                kernelY[2][0] = -1;
                kernelY[2][1] = -1;
                kernelY[2][2] = -1;

                Bitmap bmpOrig = (Bitmap)bmp.Clone();
                Gradient.Combine(bmp, kernelX, kernelY);
                picOrig.Image = bmpOrig;
                picProcessed.Image = bmp;
                //MessageBox.Show("done..");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }


        }
    }
}
