﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Windows.Forms;

namespace ConvolFilters
{
    public class Gradient
    {
        public Gradient()
        {
            //
            // TODO: Add constructor logic here
            //
        }
        public static bool Combine(Bitmap b, double[][] kernelX, double[][] kernelY)
        {  // assumes kernel is symmetric or already rotated by 180 degrees
            //  the return format is BGR, NOT RGB.
            Bitmap bSrc = (Bitmap)b.Clone();
            BitmapData bmData = b.LockBits(new Rectangle(0, 0, b.Width, b.Height),
                                ImageLockMode.ReadWrite,
                                PixelFormat.Format24bppRgb);
            BitmapData bmSrc = bSrc.LockBits(new Rectangle(0, 0, bSrc.Width, bSrc.Height),
                               ImageLockMode.ReadWrite,
                               PixelFormat.Format24bppRgb);

            int stride = bmData.Stride; // number of bytes in a row 3*b.Width + even bits
            System.IntPtr Scan0 = bmData.Scan0;
            System.IntPtr SrcScan0 = bmSrc.Scan0;

            //double cblue, cgreen, cred;
            //double cblue_x, cgreen_x, cred_x, cblue_y, cgreen_y, cred_y ;

            unsafe
            {
                byte* p = (byte*)(void*)Scan0;
                byte* pc = (byte*)(void*)SrcScan0;

                byte red, green, blue;
                int nOffset = stride - b.Width * 3;
                for (int y = 0; y < b.Height - 2; ++y)
                {
                    for (int x = 0; x < b.Width - 2; ++x)
                    {
                        double[][] bluem = new double[3][];
                        for (int i = 0; i < 3; i++)
                            bluem[i] = new double[3];
                        double[][] greenm = new double[3][];
                        for (int i = 0; i < 3; i++)
                            greenm[i] = new double[3];
                        double[][] redm = new double[3][];
                        for (int i = 0; i < 3; i++)
                            redm[i] = new double[3];
                        bluem[0][0] = pc[0];
                        greenm[0][0] = pc[1];
                        redm[0][0] = pc[2];

                        bluem[0][1] = pc[3];
                        greenm[0][1] = pc[4];
                        redm[0][1] = pc[5];

                        bluem[0][2] = pc[6];
                        greenm[0][2] = pc[7];
                        redm[0][2] = pc[8];

                        bluem[1][0] = pc[0 + stride];
                        greenm[1][0] = pc[1 + stride];
                        redm[1][0] = pc[2 + stride];

                        bluem[1][1] = pc[3 + stride];
                        greenm[1][1] = pc[4 + stride];
                        redm[1][1] = pc[5 + stride];

                        bluem[1][2] = pc[6 + stride];
                        greenm[1][2] = pc[7 + stride];
                        redm[1][2] = pc[8 + stride];

                        bluem[2][0] = pc[0 + stride * 2];
                        greenm[2][0] = pc[1 + stride * 2];
                        redm[2][0] = pc[2 + stride * 2];

                        bluem[2][1] = pc[3 + stride * 2];
                        greenm[2][1] = pc[4 + stride * 2];
                        redm[2][1] = pc[5 + stride * 2];

                        bluem[2][2] = pc[6 + stride * 2];
                        greenm[2][2] = pc[7 + stride * 2];
                        redm[2][2] = pc[8 + stride * 2];


                        double cblueX = bluem[0][0] * kernelX[0][0] +
                            bluem[0][1] * kernelX[0][1] +
                            bluem[0][2] * kernelX[0][2] +
                            bluem[1][0] * kernelX[1][0] +
                            bluem[1][1] * kernelX[1][1] +
                            bluem[1][2] * kernelX[1][2] +
                            bluem[2][0] * kernelX[2][0] +
                            bluem[2][1] * kernelX[2][1] +
                            bluem[2][2] * kernelX[2][2];
                        double cgreenX = greenm[0][0] * kernelX[0][0] +
                           greenm[0][1] * kernelX[0][1] +
                           greenm[0][2] * kernelX[0][2] +
                           greenm[1][0] * kernelX[1][0] +
                           greenm[1][1] * kernelX[1][1] +
                           greenm[1][2] * kernelX[1][2] +
                           greenm[2][0] * kernelX[2][0] +
                           greenm[2][1] * kernelX[2][1] +
                           greenm[2][2] * kernelX[2][2];

                        double credX = redm[0][0] * kernelX[0][0] +
                           redm[0][1] * kernelX[0][1] +
                           redm[0][2] * kernelX[0][2] +
                           redm[1][0] * kernelX[1][0] +
                           redm[1][1] * kernelX[1][1] +
                           redm[1][2] * kernelX[1][2] +
                           redm[2][0] * kernelX[2][0] +
                           redm[2][1] * kernelX[2][1] +
                           redm[2][2] * kernelX[2][2];
                        
                        ////////
                        double cblueY = bluem[0][0] * kernelY[0][0] +
                           bluem[0][1] * kernelY[0][1] +
                           bluem[0][2] * kernelY[0][2] +
                           bluem[1][0] * kernelY[1][0] +
                           bluem[1][1] * kernelY[1][1] +
                           bluem[1][2] * kernelY[1][2] +
                           bluem[2][0] * kernelY[2][0] +
                           bluem[2][1] * kernelY[2][1] +
                           bluem[2][2] * kernelY[2][2];
                        double cgreenY = greenm[0][0] * kernelY[0][0] +
                           greenm[0][1] * kernelY[0][1] +
                           greenm[0][2] * kernelY[0][2] +
                           greenm[1][0] * kernelY[1][0] +
                           greenm[1][1] * kernelY[1][1] +
                           greenm[1][2] * kernelY[1][2] +
                           greenm[2][0] * kernelY[2][0] +
                           greenm[2][1] * kernelY[2][1] +
                           greenm[2][2] * kernelY[2][2];

                        double credY = redm[0][0] * kernelY[0][0] +
                           redm[0][1] * kernelY[0][1] +
                           redm[0][2] * kernelY[0][2] +
                           redm[1][0] * kernelY[1][0] +
                           redm[1][1] * kernelY[1][1] +
                           redm[1][2] * kernelY[1][2] +
                           redm[2][0] * kernelY[2][0] +
                           redm[2][1] * kernelY[2][1] +
                           redm[2][2] * kernelY[2][2];

                        if (cblueY < 0) cblueY = 0;
                        if (cblueY > 255) cblueY = 255;
                        if (cgreenY < 0) cgreenY = 0;
                        if (cgreenY > 255) cgreenY = 255;
                        if (credY < 0) credY = 0;
                        if (credY > 255) credY = 255;

                        if (cblueX < 0) cblueX = 0;
                        if (cblueX > 255) cblueX = 255;
                        if (cgreenX < 0) cgreenX = 0;
                        if (cgreenX > 255) cgreenX = 255;
                        if (credX < 0) credX = 0;
                        if (credX > 255) credX = 255;

                        double cblueXY = cblueX * cblueX + cblueY * cblueY;
                        double cgreenXY = cgreenX * cgreenX + cgreenY * cgreenY;
                        double credXY = credX * credX + credY * credY;

                        double cblue = Math.Sqrt(cblueXY);
                        double cgreen = Math.Sqrt(cgreenXY);
                        double cred = Math.Sqrt(credXY);

                        if (cblue < 0) cblue = 0;
                        if (cblue > 255) cblue = 255;
                        if (cgreen < 0) cgreen = 0;
                        if (cgreen > 255) cgreen = 255;
                        if (cred < 0) cred = 0;
                        if (cred > 255) cred = 255;

                        p[3 + stride] = (byte)cblue;
                        p[4 + stride] = (byte)cgreen;
                        p[5 + stride] = (byte)cred;

                        p += 3;
                        pc += 3;
                    }
                    p += nOffset;
                    pc += nOffset;
                }
            }


            b.UnlockBits(bmData);
            bSrc.UnlockBits(bmSrc);
            return true;
        }
    }

        
    
}
