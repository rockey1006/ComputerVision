﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Mapack;

namespace PCA
{
    public partial class PCA : Form
    {
        public PCA()
        {
            InitializeComponent();
        }
        Matrix Eeigen_Face = new Matrix(10304, 50);
        Matrix IMG_Projection = new Matrix(200, 50);
        Matrix Test_Projection = new Matrix(1, 50);
        double EuDistance = 0;
        double[] EuD_List = new double[200];
        int[] Pos = new int[200];
        
        string[] Load_IMG_Train = new string[200];
        string[] Load_IMG_Test = new string[200];
        string[] result_Table = new string[200];

        private void PCAbtn_Click(object sender, EventArgs e)
        {
            String dr = @"F:\CS_PhD\SD4_SP18\Computer Vision 585\assignment 06\ATTDataSet\Training";
            DirectoryInfo di = new DirectoryInfo(dr);
            Load_IMG_Train = Directory.GetFiles(dr);
            Color Grey; double Grey2;
            int TotalN = 200; //200 imges
            int h = 112; //Height
            int w = 92;  //Width
            int Row = h * w;

            Matrix IMG_VMtx = new Matrix(Row, 200);
            Matrix mean_dataMat = new Matrix(Row, 200);

            Matrix Cov_Mtx = new Matrix(TotalN, TotalN);
            Matrix IMG_Ori = new Matrix(w, h);
            Matrix IMG_Vct = new Matrix(Row, 1);

            //Step 1. Convert 200 images to 200 92*112=10304 x 1 matrices           
            for (int f = 1; f < TotalN; f++) //for each face
            {
                int r = 0;
                string Current_IMG = Load_IMG_Train[f];
                Bitmap bmpT = new Bitmap(Current_IMG);
                for (int i = 0; i < w; i++)
                {
                    for (int j = 0; j < h; j++)
                    {
                        Grey = bmpT.GetPixel(i, j);
                        Grey2 = 0.299 * Grey.R + 0.587 * Grey.G + 0.114 * Grey.B;
                        double Pixel_Val = (double)(Grey2);
                        IMG_Ori[i, j] = Pixel_Val;
                        IMG_Vct[r++, 0] = IMG_Ori[i, j];
                    }
                }
                for (int k = 0; k < Row; k++)
                {
                    IMG_VMtx[k, f] = IMG_Vct[k, 0];
                }
            }

            Matrix IMG_Mean = new Matrix(Row, 1); // Compute the Avg.for each face
            for (int i = 0; i < Row; i++)
            {
                double SumbyRow = 0;
                for (int j = 0; j < TotalN; j++)
                {
                    SumbyRow = IMG_VMtx[i, j];
                    IMG_Mean[i, 0] += SumbyRow;
                }
                IMG_Mean[i, 0] /= TotalN;
            }
            // Step 2. Adjust ech vector by subtracting the mean vector from it
            // Centralization
            Matrix IMG_VMtx_Mean = new Matrix(Row, TotalN);
            for (int i = 0; i < Row; i++)
            {
                for (int j = 0; j < TotalN; j++)
                {
                    IMG_VMtx_Mean[i, j] = IMG_VMtx[i, j] - IMG_Mean[i, 0];
                }
            }
            // Step 3. Compute Cov. matrix by donging inner produts
            Matrix IVMtx_M_Tr = IMG_VMtx_Mean.Transpose();
            Cov_Mtx = IVMtx_M_Tr * IMG_VMtx_Mean;
  
            // Step 4. Find EigenValue of above Cov. matrix
            EigenvalueDecomposition Eigen = new EigenvalueDecomposition(Cov_Mtx);
            double[] Rev_Eigen = Eigen.RealEigenvalues;
            Array.Sort(Rev_Eigen); //Sorting by magnitude

            Matrix Eigen_Value = new Matrix(TotalN, 50); //pick up the top 50 EigenValues

            for (int i = 0; i < TotalN; i++)
            {
                for (int j = TotalN - 1; j >= TotalN - 50; j--)
                {
                    Eigen_Value[i, TotalN - j - 1] = Eigen.EigenvectorMatrix[i, j];
                }
            }
            // Step 5. Compute Eigen Faces
            Eeigen_Face = IMG_VMtx_Mean * Eigen_Value;
            // Step 6. Generate features for each face
            // Projection
            IMG_Projection = IMG_VMtx_Mean.Transpose() * Eeigen_Face;

            MessageBox.Show("PCA is done!");

            // Testing Part:
            Matrix IMG_VT = new Matrix(Row, 1);
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.InitialDirectory = "F:\\CS_PhD\\SD4_SP18\\Computer Vision 585\\Other Code\\PCA\\PCA\\ATTFaceDataSet\\Testing";
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                Bitmap bmpT = new Bitmap(ofd.FileName);
                picOrig.Image = bmpT;
            }

            //Convert the incoming image into its projection 
            Bitmap bmpT2 = new Bitmap(ofd.FileName);
            int rT = 0;
            for (int j = 0; j < w; j++)
            {
                for (int k = 0; k < h; k++)
                {
                    Grey = bmpT2.GetPixel(j, k);
                    Grey2 = 0.299 * Grey.R + 0.587 * Grey.G + 0.114 * Grey.B;
                    double Pixel_Val = Grey2;
                    IMG_Ori[j, k] = Pixel_Val;
                    IMG_VT[rT++, 0] = IMG_Ori[j, k];
                }
            }

            Matrix IMG_VMtx_MeanT = new Matrix(Row, 1);
            for (int i = 0; i < Row; i++)
            {      
               IMG_VMtx_MeanT[i, 0] = IMG_VT[i, 0] - IMG_Mean[i, 0];             
            }
            Test_Projection = IMG_VMtx_MeanT.Transpose() * Eeigen_Face;
            int n = 0;
            for (int r = 0; r < TotalN; r++)
            {
               EuDistance = 0;
               for (int c = 0; c < 50; c++)
               {
                 EuDistance += Math.Abs(Test_Projection[0, c] - IMG_Projection[r, c]) ;
               }
                 EuD_List[r] = EuDistance;
                 Pos[r] = n;
                 n++;
            }
            double a = 0; int b = 0;
            for (int l = 0; l < TotalN; l++)
            {
                for (int i = 0; i < (TotalN - 1); i++)
                {
                    if (EuD_List[i + 1] < EuD_List[i])
                    {
                        a=EuD_List[i] ;
                        b=Pos[i] ;
                        EuD_List[i] = EuD_List[i + 1];
                        Pos[i] = Pos[i + 1];
                        EuD_List[i + 1] = a;
                        Pos[i + 1] = b;
                    }
                }
            }
            // Take first five matched faces then plot them
            string Current_IMGp0 = Load_IMG_Train[Pos[0]];
            string Current_IMGp1 = Load_IMG_Train[Pos[1]];
            string Current_IMGp2 = Load_IMG_Train[Pos[2]];
            string Current_IMGp3 = Load_IMG_Train[Pos[3]];
            string Current_IMGp4 = Load_IMG_Train[Pos[4]];

            Bitmap bmpTp0 = new Bitmap(Current_IMGp0);
            Bitmap bmpTp1 = new Bitmap(Current_IMGp1);
            Bitmap bmpTp2 = new Bitmap(Current_IMGp2);
            Bitmap bmpTp3 = new Bitmap(Current_IMGp3);
            Bitmap bmpTp4 = new Bitmap(Current_IMGp4);

            picplot0.Image = bmpTp0;
            picplot1.Image = bmpTp1;
            picplot2.Image = bmpTp2;
            picplot3.Image = bmpTp3;
            picplot4.Image = bmpTp4;

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            //
        }

        private void PCA_Load(object sender, EventArgs e)
        {
            //
        }

        private void EigenFacebtn_Click(object sender, EventArgs e)
        {
            String dr = @"F:\CS_PhD\SD4_SP18\Computer Vision 585\assignment 06\ATTDataSet\Training";
            DirectoryInfo di = new DirectoryInfo(dr);
            Load_IMG_Train = Directory.GetFiles(dr);
            Color Grey; double Grey2;
            int TotalN = 200; //200 imges
            int h = 112; //Height
            int w = 92;  //Width
            int Row = h * w;

            Matrix IMG_VMtx = new Matrix(Row, 200);
            Matrix mean_dataMat = new Matrix(Row, 200);

            Matrix Cov_Mtx = new Matrix(TotalN, TotalN);
            Matrix IMG_Ori = new Matrix(w, h);
            Matrix IMG_Vct = new Matrix(Row, 1);

            //Step 1. Convert 200 images to 200 92*112=10304 x 1 matrices           
            for (int f = 1; f < TotalN; f++) //for each face
            {
                int r = 0;
                string Current_IMG = Load_IMG_Train[f];
                Bitmap bmpT = new Bitmap(Current_IMG);
                for (int i = 0; i < w; i++)
                {
                    for (int j = 0; j < h; j++)
                    {
                        Grey = bmpT.GetPixel(i, j);
                        Grey2 = 0.299 * Grey.R + 0.587 * Grey.G + 0.114 * Grey.B;
                        double Pixel_Val = (double)(Grey2);
                        IMG_Ori[i, j] = Pixel_Val;
                        IMG_Vct[r++, 0] = IMG_Ori[i, j];
                    }
                }
                for (int k = 0; k < Row; k++)
                {
                    IMG_VMtx[k, f] = IMG_Vct[k, 0];
                }
            }

            Matrix IMG_Mean = new Matrix(Row, 1); // Compute the Avg.for each face
            for (int i = 0; i < Row; i++)
            {
                double SumbyRow = 0;
                for (int j = 0; j < TotalN; j++)
                {
                    SumbyRow = IMG_VMtx[i, j];
                    IMG_Mean[i, 0] += SumbyRow;
                }
                IMG_Mean[i, 0] /= TotalN;
            }
            // Step 2. Adjust ech vector by subtracting the mean vector from it
            // Centralization
            Matrix IMG_VMtx_Mean = new Matrix(Row, TotalN);
            for (int i = 0; i < Row; i++)
            {
                for (int j = 0; j < TotalN; j++)
                {
                    IMG_VMtx_Mean[i, j] = IMG_VMtx[i, j] - IMG_Mean[i, 0];
                }
            }
            // Step 3. Compute Cov. matrix by donging inner produts
            Matrix IVMtx_M_Tr = IMG_VMtx_Mean.Transpose();
            Cov_Mtx = IVMtx_M_Tr * IMG_VMtx_Mean;

            // Step 4. Find EigenValue of above Cov. matrix
            EigenvalueDecomposition Eigen = new EigenvalueDecomposition(Cov_Mtx);
            double[] Rev_Eigen = Eigen.RealEigenvalues;
            Array.Sort(Rev_Eigen); //Sorting by magnitude

            Matrix Eigen_Value = new Matrix(TotalN, 50); //pick up the top 50 EigenValues

            for (int i = 0; i < TotalN; i++)
            {
                for (int j = TotalN - 1; j >= TotalN - 50; j--)
                {
                    Eigen_Value[i, TotalN - j - 1] = Eigen.EigenvectorMatrix[i, j];
                }
            }
            // Step 5. Compute Eigen Faces
            Eeigen_Face = IMG_VMtx_Mean * Eigen_Value;
            // Step 6. Generate features for each face
            // Projection
            IMG_Projection = IMG_VMtx_Mean.Transpose() * Eeigen_Face;

            Bitmap bmpEF0 = new Bitmap(Load_IMG_Train[0]);
            //Bitmap bmpEF1 = new Bitmap(picOrig.Image);
            //Bitmap bmpEF2 = new Bitmap(picOrig.Image);
            int rR = 0;
            string sNEF = txtBox.Text.ToString();
            
            if (sNEF == "") { MessageBox.Show("Please enter a number less than 50!"); }
            else
            {
                int NEF = Convert.ToInt32(sNEF);
                for (int i = 0; i < w; i++)
                {

                    for (int j = 0; j < h; j++)
                    {
                        int greyRe0 = (int)Eeigen_Face[rR++, NEF];
                        if (greyRe0 < 0) { greyRe0 = 0; }
                        if (greyRe0 > 255) { greyRe0 = 255; }
                        bmpEF0.SetPixel(i, j, Color.FromArgb(greyRe0, greyRe0, greyRe0));

                    }
                }
                picProcessed0.Image = bmpEF0;
            }
            
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            //
        }
    }
}


    
