﻿namespace PCA
{
    partial class PCA
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.PCAbtn = new System.Windows.Forms.Button();
            this.dataSet1 = new System.Data.DataSet();
            this.picOrig = new System.Windows.Forms.PictureBox();
            this.picplot0 = new System.Windows.Forms.PictureBox();
            this.picplot1 = new System.Windows.Forms.PictureBox();
            this.picplot2 = new System.Windows.Forms.PictureBox();
            this.picplot3 = new System.Windows.Forms.PictureBox();
            this.picplot4 = new System.Windows.Forms.PictureBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.EigenFacebtn = new System.Windows.Forms.Button();
            this.picProcessed0 = new System.Windows.Forms.PictureBox();
            this.txtBox = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picOrig)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picplot0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picplot1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picplot2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picplot3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picplot4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picProcessed0)).BeginInit();
            this.SuspendLayout();
            // 
            // PCAbtn
            // 
            this.PCAbtn.Location = new System.Drawing.Point(51, 31);
            this.PCAbtn.Margin = new System.Windows.Forms.Padding(2);
            this.PCAbtn.Name = "PCAbtn";
            this.PCAbtn.Size = new System.Drawing.Size(92, 37);
            this.PCAbtn.TabIndex = 1;
            this.PCAbtn.Text = "PCA";
            this.PCAbtn.UseVisualStyleBackColor = true;
            this.PCAbtn.Click += new System.EventHandler(this.PCAbtn_Click);
            // 
            // dataSet1
            // 
            this.dataSet1.DataSetName = "NewDataSet";
            // 
            // picOrig
            // 
            this.picOrig.Location = new System.Drawing.Point(51, 88);
            this.picOrig.Name = "picOrig";
            this.picOrig.Size = new System.Drawing.Size(92, 112);
            this.picOrig.TabIndex = 3;
            this.picOrig.TabStop = false;
            // 
            // picplot0
            // 
            this.picplot0.Location = new System.Drawing.Point(246, 88);
            this.picplot0.Name = "picplot0";
            this.picplot0.Size = new System.Drawing.Size(92, 112);
            this.picplot0.TabIndex = 4;
            this.picplot0.TabStop = false;
            this.picplot0.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // picplot1
            // 
            this.picplot1.Location = new System.Drawing.Point(391, 88);
            this.picplot1.Name = "picplot1";
            this.picplot1.Size = new System.Drawing.Size(92, 112);
            this.picplot1.TabIndex = 5;
            this.picplot1.TabStop = false;
            // 
            // picplot2
            // 
            this.picplot2.Location = new System.Drawing.Point(536, 88);
            this.picplot2.Name = "picplot2";
            this.picplot2.Size = new System.Drawing.Size(92, 112);
            this.picplot2.TabIndex = 6;
            this.picplot2.TabStop = false;
            // 
            // picplot3
            // 
            this.picplot3.Location = new System.Drawing.Point(679, 88);
            this.picplot3.Name = "picplot3";
            this.picplot3.Size = new System.Drawing.Size(92, 112);
            this.picplot3.TabIndex = 7;
            this.picplot3.TabStop = false;
            // 
            // picplot4
            // 
            this.picplot4.Location = new System.Drawing.Point(825, 88);
            this.picplot4.Name = "picplot4";
            this.picplot4.Size = new System.Drawing.Size(92, 112);
            this.picplot4.TabIndex = 8;
            this.picplot4.TabStop = false;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(51, 220);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(92, 20);
            this.textBox1.TabIndex = 9;
            this.textBox1.Text = "Unkown Image";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(536, 220);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(92, 20);
            this.textBox2.TabIndex = 10;
            this.textBox2.Text = "Detection Result";
            this.textBox2.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // EigenFacebtn
            // 
            this.EigenFacebtn.Location = new System.Drawing.Point(51, 337);
            this.EigenFacebtn.Name = "EigenFacebtn";
            this.EigenFacebtn.Size = new System.Drawing.Size(92, 37);
            this.EigenFacebtn.TabIndex = 11;
            this.EigenFacebtn.Text = "Eigen Face";
            this.EigenFacebtn.UseVisualStyleBackColor = true;
            this.EigenFacebtn.Click += new System.EventHandler(this.EigenFacebtn_Click);
            // 
            // picProcessed0
            // 
            this.picProcessed0.Location = new System.Drawing.Point(246, 337);
            this.picProcessed0.Name = "picProcessed0";
            this.picProcessed0.Size = new System.Drawing.Size(92, 112);
            this.picProcessed0.TabIndex = 12;
            this.picProcessed0.TabStop = false;
            // 
            // txtBox
            // 
            this.txtBox.Location = new System.Drawing.Point(112, 419);
            this.txtBox.Name = "txtBox";
            this.txtBox.Size = new System.Drawing.Size(31, 20);
            this.txtBox.TabIndex = 15;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(51, 380);
            this.textBox3.Multiline = true;
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(92, 33);
            this.textBox3.TabIndex = 16;
            this.textBox3.Text = "Put the # of eigen Face (<50):";
            // 
            // PCA
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(971, 484);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.txtBox);
            this.Controls.Add(this.picProcessed0);
            this.Controls.Add(this.EigenFacebtn);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.picplot4);
            this.Controls.Add(this.picplot3);
            this.Controls.Add(this.picplot2);
            this.Controls.Add(this.picplot1);
            this.Controls.Add(this.picplot0);
            this.Controls.Add(this.picOrig);
            this.Controls.Add(this.PCAbtn);
            this.Name = "PCA";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.PCA_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picOrig)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picplot0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picplot1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picplot2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picplot3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picplot4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picProcessed0)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button PCAbtn;
        private System.Data.DataSet dataSet1;
        private System.Windows.Forms.PictureBox picOrig;
        private System.Windows.Forms.PictureBox picplot0;
        private System.Windows.Forms.PictureBox picplot1;
        private System.Windows.Forms.PictureBox picplot2;
        private System.Windows.Forms.PictureBox picplot3;
        private System.Windows.Forms.PictureBox picplot4;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Button EigenFacebtn;
        private System.Windows.Forms.PictureBox picProcessed0;
        private System.Windows.Forms.TextBox txtBox;
        private System.Windows.Forms.TextBox textBox3;
    }
}

